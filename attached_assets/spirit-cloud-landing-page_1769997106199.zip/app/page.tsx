"use client";

import { useState } from "react";
import { AnimatePresence } from "framer-motion";
import { LandingScreen } from "@/components/landing-screen";
import { QuestionScreen } from "@/components/question-screen";

type Screen = "landing" | "questions";

export default function Home() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("landing");

  const handleEnter = () => {
    setCurrentScreen("questions");
  };

  const handleBack = () => {
    setCurrentScreen("landing");
  };

  return (
    <main className="min-h-screen bg-background text-foreground selection:bg-foreground/10">
      <AnimatePresence mode="wait">
        {currentScreen === "landing" && (
          <LandingScreen key="landing" onEnter={handleEnter} />
        )}
        {currentScreen === "questions" && (
          <QuestionScreen key="questions" onBack={handleBack} />
        )}
      </AnimatePresence>
    </main>
  );
}
