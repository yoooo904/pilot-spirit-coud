export const questions = [
  {
    id: 1,
    question: "지금 이 순간, 당신이 가장 피하고 싶은 감정은 무엇인가요?",
    category: "감정",
    depth: 0.1,
    position: "center" as const, // 시작점
  },
  {
    id: 2,
    question: "만약 실패할 수 없다면, 당신은 무엇을 시도할 건가요?",
    category: "두려움",
    depth: 0.2,
    position: "right" as const, // 오른쪽으로 꺾임
  },
  {
    id: 3,
    question: "당신이 마지막으로 진심으로 웃었던 순간은 언제였나요?",
    category: "행복",
    depth: 0.3,
    position: "center" as const, // 다시 중앙
  },
  {
    id: 4,
    question: "세상에서 사라져도 괜찮다고 느꼈던 적이 있나요?",
    category: "존재",
    depth: 0.4,
    position: "left" as const, // 왼쪽으로 꺾임
  },
  {
    id: 5,
    question: "당신이 가장 오래 간직한 비밀은 무엇인가요?",
    category: "내면",
    depth: 0.5,
    position: "left" as const, // 계속 왼쪽
  },
  {
    id: 6,
    question: "10년 전의 당신에게 해주고 싶은 말이 있다면요?",
    category: "시간",
    depth: 0.6,
    position: "center" as const, // 중앙으로 돌아옴
  },
  {
    id: 7,
    question: "당신은 어떤 모습의 자신을 사랑하기 어려운가요?",
    category: "자아",
    depth: 0.7,
    position: "right" as const, // 오른쪽으로
  },
  {
    id: 8,
    question: "지금 가장 필요한 것이 있다면, 그것은 무엇인가요?",
    category: "필요",
    depth: 0.75,
    position: "right" as const, // 계속 오른쪽
  },
  {
    id: 9,
    question: "당신이 진정으로 원하는 것을 알고 있나요?",
    category: "욕망",
    depth: 0.8,
    position: "center" as const, // 중앙
  },
  {
    id: 10,
    question: "오늘 하루, 당신은 자신에게 얼마나 솔직했나요?",
    category: "진실",
    depth: 0.85,
    position: "left" as const, // 왼쪽
  },
  {
    id: 11,
    question: "당신이 가장 두려워하는 관계의 끝은 어떤 모습인가요?",
    category: "관계",
    depth: 0.9,
    position: "center" as const, // 중앙으로
  },
  {
    id: 12,
    question: "침묵 속에서 당신은 무엇을 듣나요?",
    category: "고요",
    depth: 1.0,
    position: "center" as const, // 최종 중앙 (귀환)
  },
];

export type Question = (typeof questions)[number];
