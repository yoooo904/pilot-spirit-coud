"use client";

import { motion } from "framer-motion";
import { useMemo } from "react";

interface OrbProps {
  depth?: number;
  isTransitioning?: boolean;
  transitionDirection?: "left" | "right" | "center";
}

export function Orb({ 
  depth = 0, 
  isTransitioning = false,
  transitionDirection = "center" 
}: OrbProps) {
  // Transition offset - moves during transition then returns to center
  const transitionOffset = useMemo(() => {
    if (!isTransitioning) return 0;
    switch (transitionDirection) {
      case "left": return -180;
      case "right": return 180;
      default: return 0;
    }
  }, [isTransitioning, transitionDirection]);

  const orbStyles = useMemo(() => {
    const baseSize = 180;
    const sizeMultiplier = 1 - depth * 0.3;
    const size = baseSize * sizeMultiplier;
    
    // Color journey - cool to warm
    const hue = 220 - depth * 70;
    const warmHue = 35;
    const saturation = 6 + depth * 40;
    const lightness = 88 + depth * 8;
    
    const glowIntensity = 0.08 + depth * 0.5;
    const coreGlow = 0.35 + depth * 0.55;
    
    return { size, hue, warmHue, saturation, lightness, glowIntensity, coreGlow };
  }, [depth]);

  const breatheDuration = 4.5 - depth * 1.2;

  // Hexagon geometry helpers
  const hexPoints = (cx: number, cy: number, r: number, offset = 0): string => {
    return Array.from({ length: 6 }, (_, i) => {
      const angle = (Math.PI / 3) * i + offset;
      const x = cx + r * Math.cos(angle);
      const y = cy + r * Math.sin(angle);
      return `${x},${y}`;
    }).join(" ");
  };

  return (
    <motion.div 
      className="relative"
      style={{ 
        width: orbStyles.size * 2, 
        height: orbStyles.size * 2,
      }}
      animate={{
        x: transitionOffset,
        rotate: isTransitioning ? (transitionDirection === "left" ? -8 : transitionDirection === "right" ? 8 : 0) : 0,
      }}
      transition={{ 
        x: { 
          duration: isTransitioning ? 0.8 : 1.2, 
          ease: isTransitioning ? [0.4, 0, 0.6, 1] : [0.2, 0, 0.2, 1] 
        },
        rotate: { duration: 0.8, ease: "easeInOut" },
      }}
    >
      {/* Outer ambient glow */}
      <motion.div
        className="absolute inset-0"
        style={{
          background: `radial-gradient(circle at center, 
            hsla(${orbStyles.hue}, ${orbStyles.saturation}%, ${orbStyles.lightness}%, ${orbStyles.glowIntensity * 0.12}) 0%, 
            transparent 70%)`,
          filter: "blur(50px)",
        }}
        animate={{
          scale: [1, 1.12, 1],
          opacity: [0.35, 0.55, 0.35],
        }}
        transition={{
          duration: breatheDuration + 2,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Main orb container */}
      <motion.div
        className="absolute inset-0 flex items-center justify-center"
        animate={{
          scale: [1, 1.03, 1],
        }}
        transition={{
          duration: breatheDuration,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        {/* Outermost delicate ring */}
        <motion.svg
          viewBox="0 0 200 200"
          className="absolute"
          style={{
            width: orbStyles.size * 1.6,
            height: orbStyles.size * 1.6,
          }}
          animate={{
            rotate: [0, 360],
            scale: [1, 1.015, 1],
          }}
          transition={{
            rotate: { duration: 120, repeat: Infinity, ease: "linear" },
            scale: { duration: breatheDuration + 1.5, repeat: Infinity, ease: "easeInOut" },
          }}
        >
          <defs>
            <linearGradient id={`outerRing-${depth}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={`hsla(${orbStyles.hue}, ${orbStyles.saturation}%, ${orbStyles.lightness}%, ${0.08 + depth * 0.12})`} />
              <stop offset="100%" stopColor={`hsla(${depth > 0.5 ? orbStyles.warmHue : orbStyles.hue - 20}, ${orbStyles.saturation}%, ${orbStyles.lightness}%, ${0.04 + depth * 0.08})`} />
            </linearGradient>
          </defs>
          <circle
            cx="100"
            cy="100"
            r="95"
            fill="none"
            stroke={`url(#outerRing-${depth})`}
            strokeWidth={0.3}
            strokeDasharray="2 8"
            opacity={0.4 + depth * 0.2}
          />
        </motion.svg>

        {/* Outer mesh - refined hexagonal layers */}
        <motion.svg
          viewBox="0 0 200 200"
          className="absolute"
          style={{
            width: orbStyles.size * 1.35,
            height: orbStyles.size * 1.35,
          }}
          animate={{
            rotate: [0, 360],
            scale: [1, 1.02, 1],
          }}
          transition={{
            rotate: { duration: 80, repeat: Infinity, ease: "linear" },
            scale: { duration: breatheDuration + 0.5, repeat: Infinity, ease: "easeInOut" },
          }}
        >
          <defs>
            <linearGradient id={`meshGrad-${depth}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={`hsla(${orbStyles.hue}, ${orbStyles.saturation + 10}%, ${orbStyles.lightness}%, ${0.12 + depth * 0.18})`} />
              <stop offset="50%" stopColor={`hsla(${orbStyles.hue - 15}, ${orbStyles.saturation + 5}%, ${orbStyles.lightness}%, ${0.06 + depth * 0.1})`} />
              <stop offset="100%" stopColor={`hsla(${depth > 0.5 ? orbStyles.warmHue : orbStyles.hue}, ${orbStyles.saturation}%, ${orbStyles.lightness}%, ${0.08 + depth * 0.12})`} />
            </linearGradient>
          </defs>
          
          {/* Multi-layer hexagons */}
          {[70, 55, 40].map((radius, layerIndex) => (
            <polygon
              key={`hex-${layerIndex}`}
              points={hexPoints(100, 100, radius, (layerIndex * Math.PI) / 12)}
              fill="none"
              stroke={`url(#meshGrad-${depth})`}
              strokeWidth={0.25 + depth * 0.2 - layerIndex * 0.05}
              opacity={0.35 + depth * 0.25 - layerIndex * 0.08}
            />
          ))}

          {/* Connecting radial lines */}
          {[...Array(12)].map((_, i) => {
            const angle = (i * Math.PI) / 6;
            const innerR = 28;
            const outerR = 72;
            return (
              <line
                key={`radial-${i}`}
                x1={100 + Math.cos(angle) * innerR}
                y1={100 + Math.sin(angle) * innerR}
                x2={100 + Math.cos(angle) * outerR}
                y2={100 + Math.sin(angle) * outerR}
                stroke={`url(#meshGrad-${depth})`}
                strokeWidth={0.2 + depth * 0.15}
                opacity={i % 2 === 0 ? 0.3 + depth * 0.2 : 0.15 + depth * 0.1}
              />
            );
          })}
        </motion.svg>

        {/* Inner geometric layer - counter-rotating */}
        <motion.svg
          viewBox="0 0 200 200"
          className="absolute"
          style={{
            width: orbStyles.size * 1.0,
            height: orbStyles.size * 1.0,
          }}
          animate={{
            rotate: [0, -360],
            scale: [1, 1.025, 1],
          }}
          transition={{
            rotate: { duration: 100, repeat: Infinity, ease: "linear" },
            scale: { duration: breatheDuration, repeat: Infinity, ease: "easeInOut", delay: 0.15 },
          }}
        >
          <defs>
            <linearGradient id={`innerGrad-${depth}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={`hsla(${orbStyles.hue}, ${orbStyles.saturation + 20}%, 92%, ${0.2 + depth * 0.25})`} />
              <stop offset="100%" stopColor={`hsla(${depth > 0.6 ? orbStyles.warmHue : orbStyles.hue - 25}, ${orbStyles.saturation + 15}%, 94%, ${0.12 + depth * 0.18})`} />
            </linearGradient>
          </defs>
          
          {/* Nested hexagons with varied offsets */}
          {[48, 36, 24].map((radius, i) => (
            <polygon
              key={`inner-hex-${i}`}
              points={hexPoints(100, 100, radius, (i * Math.PI) / 18)}
              fill="none"
              stroke={`url(#innerGrad-${depth})`}
              strokeWidth={0.3 + depth * 0.25}
              opacity={0.4 + depth * 0.3 - i * 0.06}
            />
          ))}

          {/* Fine cross-connection lines */}
          {[...Array(6)].map((_, i) => {
            const angle1 = (i * Math.PI) / 3;
            const angle2 = angle1 + Math.PI / 6;
            return (
              <g key={`cross-${i}`}>
                <line
                  x1={100 + Math.cos(angle1) * 24}
                  y1={100 + Math.sin(angle1) * 24}
                  x2={100 + Math.cos(angle2) * 48}
                  y2={100 + Math.sin(angle2) * 48}
                  stroke={`url(#innerGrad-${depth})`}
                  strokeWidth={0.2}
                  opacity={0.25 + depth * 0.2}
                />
              </g>
            );
          })}
        </motion.svg>

        {/* Core glow sphere */}
        <motion.div
          className="absolute rounded-full"
          style={{
            width: orbStyles.size * 0.55,
            height: orbStyles.size * 0.55,
            background: `radial-gradient(circle at 38% 38%, 
              hsla(0, 0%, 100%, ${orbStyles.coreGlow}) 0%, 
              hsla(${depth > 0.5 ? orbStyles.warmHue : orbStyles.hue}, ${orbStyles.saturation + 25}%, 94%, ${orbStyles.coreGlow * 0.65}) 28%,
              hsla(${orbStyles.hue}, ${orbStyles.saturation + 12}%, ${orbStyles.lightness}%, ${orbStyles.coreGlow * 0.35}) 55%,
              hsla(${orbStyles.hue + 15}, ${orbStyles.saturation}%, ${orbStyles.lightness - 8}%, ${orbStyles.coreGlow * 0.12}) 80%,
              transparent 100%)`,
            boxShadow: `
              0 0 ${25 + depth * 50}px hsla(${depth > 0.5 ? orbStyles.warmHue : orbStyles.hue}, ${orbStyles.saturation}%, ${orbStyles.lightness}%, ${0.18 + depth * 0.25}),
              inset 0 0 ${18 + depth * 25}px hsla(0, 0%, 100%, ${0.08 + depth * 0.12})
            `,
          }}
          animate={{
            scale: [1, 1.05, 1],
            opacity: [0.92, 1, 0.92],
          }}
          transition={{
            duration: breatheDuration - 0.4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        {/* Inner bright nucleus */}
        <motion.div
          className="absolute rounded-full"
          style={{
            width: orbStyles.size * 0.2,
            height: orbStyles.size * 0.2,
            background: `radial-gradient(circle at 42% 42%, 
              hsla(0, 0%, 100%, ${0.92 + depth * 0.08}) 0%, 
              hsla(${depth > 0.7 ? orbStyles.warmHue : orbStyles.hue - 10}, ${orbStyles.saturation + 30}%, 96%, 0.55) 45%, 
              transparent 100%)`,
            boxShadow: `0 0 ${12 + depth * 22}px hsla(${depth > 0.5 ? orbStyles.warmHue : orbStyles.hue}, 45%, 92%, ${0.25 + depth * 0.35})`,
          }}
          animate={{
            scale: [1, 1.12, 1],
            opacity: [0.85, 1, 0.85],
          }}
          transition={{
            duration: breatheDuration - 0.8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        {/* Orbiting particles - golden angle distribution */}
        {[...Array(Math.floor(6 + depth * 7))].map((_, i) => {
          const orbitRadius = 45 + (i % 4) * 18;
          const startAngle = (i * 137.508 * Math.PI) / 180; // Golden angle
          const duration = 10 + i * 0.6;
          const size = 1.2 + depth * 0.8 + (i % 3) * 0.3;
          
          return (
            <motion.div
              key={i}
              className="absolute rounded-full"
              style={{
                width: size,
                height: size,
                backgroundColor: `hsla(${depth > 0.6 ? orbStyles.warmHue : orbStyles.hue}, ${orbStyles.saturation + 35}%, 94%, ${0.45 + depth * 0.35})`,
                boxShadow: `0 0 ${3 + depth * 4}px hsla(${orbStyles.hue}, 45%, 92%, 0.4)`,
                top: "50%",
                left: "50%",
              }}
              animate={{
                x: [
                  Math.cos(startAngle) * orbitRadius,
                  Math.cos(startAngle + Math.PI) * orbitRadius,
                  Math.cos(startAngle + Math.PI * 2) * orbitRadius,
                ],
                y: [
                  Math.sin(startAngle) * orbitRadius,
                  Math.sin(startAngle + Math.PI) * orbitRadius,
                  Math.sin(startAngle + Math.PI * 2) * orbitRadius,
                ],
                opacity: [0.25, 0.75 + depth * 0.2, 0.25],
              }}
              transition={{
                duration,
                repeat: Infinity,
                ease: "linear",
                delay: i * 0.15,
              }}
            />
          );
        })}

        {/* Depth-based accent elements */}
        {depth > 0.35 && (
          <>
            {/* Outer pulse ring */}
            <motion.div
              className="absolute rounded-full"
              style={{
                width: orbStyles.size * 1.15,
                height: orbStyles.size * 1.15,
                border: `1px solid hsla(${depth > 0.7 ? orbStyles.warmHue : orbStyles.hue}, ${orbStyles.saturation + 8}%, ${orbStyles.lightness}%, ${(depth - 0.35) * 0.2})`,
              }}
              animate={{
                scale: [1, 1.08, 1],
                opacity: [(depth - 0.35) * 0.35, (depth - 0.35) * 0.5, (depth - 0.35) * 0.35],
              }}
              transition={{
                duration: breatheDuration + 1.5,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          </>
        )}
      </motion.div>
    </motion.div>
  );
}
