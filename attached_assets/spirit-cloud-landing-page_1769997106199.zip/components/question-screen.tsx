"use client";

import React from "react"

import { motion, AnimatePresence } from "framer-motion";
import { useState, useCallback, useMemo, useEffect } from "react";
import { Orb } from "./orb";
import { questions } from "@/lib/questions";

interface QuestionScreenProps {
  onBack: () => void;
}

export function QuestionScreen({ onBack }: QuestionScreenProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [transitionDirection, setTransitionDirection] = useState<"left" | "right" | "center">("center");
  const [isRecording, setIsRecording] = useState(false);

  const currentQuestion = questions[currentIndex];
  const depth = currentQuestion.depth;
  const direction = currentQuestion.position;

  // Reset orb position after transition
  useEffect(() => {
    if (isTransitioning) {
      const timer = setTimeout(() => {
        setIsTransitioning(false);
        setTransitionDirection("center");
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, [isTransitioning]);

  // Background evolves with depth
  const backgroundColor = useMemo(() => {
    const r = Math.round(5 + depth * 28);
    const g = Math.round(5 + depth * 26);
    const b = Math.round(7 + depth * 20);
    return `rgb(${r}, ${g}, ${b})`;
  }, [depth]);

  // Ambient glow
  const ambientGradient = useMemo(() => {
    const opacity = 0.025 + depth * 0.08;
    const warmth = depth > 0.5 ? 40 : 220;
    
    return `radial-gradient(ellipse 65% 55% at 50% 45%, 
      hsla(${warmth}, ${12 + depth * 25}%, ${50 + depth * 35}%, ${opacity}) 0%, 
      transparent 60%)`;
  }, [depth]);

  const handleAdvance = useCallback(() => {
    if (isTransitioning) return;
    
    // Set transition direction based on next question's position
    const nextIndex = (currentIndex + 1) % questions.length;
    const nextDirection = questions[nextIndex].position;
    setTransitionDirection(nextDirection);
    setIsTransitioning(true);
    
    setTimeout(() => {
      setCurrentIndex(nextIndex);
    }, 400);
  }, [isTransitioning, currentIndex]);

  const handleRecordToggle = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    setIsRecording(prev => !prev);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1.5 }}
      className="min-h-screen flex flex-col items-center justify-center px-6 py-12 relative cursor-pointer overflow-hidden"
      onClick={handleAdvance}
      style={{ backgroundColor }}
    >
      {/* Animated background */}
      <motion.div
        className="absolute inset-0"
        animate={{ backgroundColor }}
        transition={{ duration: 1.5, ease: "easeInOut" }}
      />

      {/* Ambient glow */}
      <motion.div
        className="absolute inset-0"
        animate={{ background: ambientGradient }}
        transition={{ duration: 1.2, ease: "easeInOut" }}
      />

      {/* Fog layers for depth */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `linear-gradient(to bottom, 
            transparent 0%, 
            rgba(255,255,255,${0.008 + depth * 0.015}) 35%, 
            rgba(255,255,255,${0.015 + depth * 0.025}) 65%, 
            transparent 100%)`,
        }}
      />

      {/* Vignette */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        animate={{
          background: `radial-gradient(ellipse at center, 
            transparent ${30 + depth * 18}%, 
            rgba(0,0,0,${0.55 - depth * 0.2}) 100%)`,
        }}
        transition={{ duration: 1.5 }}
      />

      {/* Depth progress - vertical line */}
      <motion.div
        className="absolute left-6 md:left-10 top-1/2 -translate-y-1/2 w-px h-28 md:h-36 rounded-full overflow-hidden"
        style={{ backgroundColor: `rgba(255,255,255,${0.05 + depth * 0.03})` }}
      >
        <motion.div
          className="absolute bottom-0 left-0 w-full rounded-full"
          style={{ 
            backgroundColor: `rgba(255,255,255,${0.18 + depth * 0.22})`,
            boxShadow: depth > 0.5 ? `0 0 8px rgba(255,255,255,${depth * 0.2})` : 'none'
          }}
          animate={{ height: `${depth * 100}%` }}
          transition={{ duration: 1.2, ease: "easeOut" }}
        />
      </motion.div>

      {/* Back button */}
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.8 }}
        onClick={(e) => {
          e.stopPropagation();
          onBack();
        }}
        className="absolute top-6 md:top-8 left-6 md:left-10 text-white/18 hover:text-white/35 transition-colors text-xs tracking-[0.2em] uppercase font-sans z-20"
      >
        Spirit Cloud
      </motion.button>

      {/* Question counter */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.8 }}
        className="absolute top-6 md:top-8 right-6 md:right-10 text-white/12 text-xs font-sans tracking-wider z-20"
      >
        {String(currentIndex + 1).padStart(2, "0")}
      </motion.div>

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center w-full max-w-4xl">
        {/* Category */}
        <AnimatePresence mode="wait">
          <motion.div
            key={`category-${currentQuestion.id}`}
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: 0.5 }}
            className="mb-6 md:mb-8"
          >
            <span 
              className="text-xs tracking-[0.4em] uppercase font-sans"
              style={{ color: `rgba(255, 255, 255, ${0.15 + depth * 0.12})` }}
            >
              {currentQuestion.category}
            </span>
          </motion.div>
        </AnimatePresence>

        {/* Orb - moves during transition, returns to center */}
        <motion.div
          className="mb-8 md:mb-10"
          layout
          transition={{ duration: 1, ease: [0.4, 0, 0.2, 1] }}
        >
          <Orb 
            depth={depth} 
            isTransitioning={isTransitioning}
            transitionDirection={transitionDirection}
          />
        </motion.div>

        {/* Question */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestion.id}
            initial={{ opacity: 0, y: 35, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -30, scale: 1.03 }}
            transition={{ duration: 0.85, ease: "easeOut" }}
            className="max-w-md md:max-w-lg text-center px-4"
          >
            <h2 
              className="font-serif text-lg md:text-xl lg:text-2xl leading-relaxed text-balance"
              style={{ 
                color: `rgba(255, 255, 255, ${0.72 + depth * 0.22})`,
                textShadow: depth > 0.6 ? `0 0 35px rgba(255,255,255,${(depth - 0.6) * 0.18})` : 'none',
              }}
            >
              {currentQuestion.question}
            </h2>
          </motion.div>
        </AnimatePresence>

        {/* Voice response button - abstract, minimal */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.8 }}
          onClick={handleRecordToggle}
          className="mt-10 md:mt-14 relative group"
        >
          {/* Outer ring */}
          <motion.div
            className="w-14 h-14 md:w-16 md:h-16 rounded-full relative flex items-center justify-center"
            style={{
              background: isRecording 
                ? `radial-gradient(circle, rgba(255,255,255,0.06) 0%, transparent 70%)`
                : `radial-gradient(circle, rgba(255,255,255,0.025) 0%, transparent 70%)`,
              boxShadow: isRecording 
                ? `0 0 30px rgba(255,255,255,0.08), inset 0 0 20px rgba(255,255,255,0.03)`
                : `0 0 20px rgba(255,255,255,0.03)`,
            }}
            animate={isRecording ? {
              scale: [1, 1.08, 1],
            } : {}}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            {/* Border ring */}
            <motion.div
              className="absolute inset-0 rounded-full"
              style={{
                border: `1px solid rgba(255,255,255,${isRecording ? 0.15 : 0.06})`,
              }}
              animate={isRecording ? {
                scale: [1, 1.15, 1],
                opacity: [0.15, 0.25, 0.15],
              } : {}}
              transition={{
                duration: 2.5,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />

            {/* Inner core - breathing dot */}
            <motion.div
              className="rounded-full"
              style={{
                width: isRecording ? 10 : 6,
                height: isRecording ? 10 : 6,
                backgroundColor: `rgba(255,255,255,${isRecording ? 0.45 : 0.18})`,
                boxShadow: isRecording 
                  ? `0 0 15px rgba(255,255,255,0.3), 0 0 30px rgba(255,255,255,0.1)`
                  : `0 0 8px rgba(255,255,255,0.1)`,
              }}
              animate={isRecording ? {
                scale: [1, 1.4, 1],
                opacity: [0.45, 0.7, 0.45],
              } : {
                scale: [1, 1.15, 1],
                opacity: [0.18, 0.28, 0.18],
              }}
              transition={{
                duration: isRecording ? 1.2 : 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />

            {/* Recording waves */}
            {isRecording && (
              <>
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute rounded-full"
                    style={{
                      border: `1px solid rgba(255,255,255,${0.08 - i * 0.02})`,
                    }}
                    initial={{ width: 20, height: 20, opacity: 0.15 }}
                    animate={{
                      width: [20, 60],
                      height: [20, 60],
                      opacity: [0.15, 0],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: i * 0.5,
                      ease: "easeOut",
                    }}
                  />
                ))}
              </>
            )}
          </motion.div>

          {/* Subtle hint text */}
          <motion.span
            className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-sans whitespace-nowrap"
            style={{ 
              color: `rgba(255,255,255,${isRecording ? 0.2 : 0.08})`,
              letterSpacing: '0.12em',
            }}
            animate={{
              opacity: isRecording ? [0.2, 0.3, 0.2] : 0.08,
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            {isRecording ? 'listening' : 'speak'}
          </motion.span>
        </motion.button>
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(Math.floor(4 + depth * 6))].map((_, i) => {
          const size = 0.8 + Math.random() * 0.5;
          const startX = Math.random() * 100;
          const duration = 12 + Math.random() * 8;
          
          return (
            <motion.div
              key={i}
              className="absolute rounded-full"
              style={{
                width: size,
                height: size,
                left: `${startX}%`,
                backgroundColor: `rgba(255, 255, 255, ${0.12 + depth * 0.15})`,
              }}
              initial={{ y: "110vh", opacity: 0 }}
              animate={{
                y: "-10vh",
                opacity: [0, 0.35 + depth * 0.25, 0],
              }}
              transition={{
                duration,
                repeat: Infinity,
                delay: i * 0.6,
                ease: "linear",
              }}
            />
          );
        })}
      </div>

      {/* Bottom hint */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 0.8 }}
        className="absolute bottom-6 md:bottom-8 text-white/08 text-xs tracking-[0.12em] font-sans"
      >
        {depth < 0.35 ? "tap to continue" : depth < 0.65 ? "deeper" : "into the quiet"}
      </motion.p>
    </motion.div>
  );
}
